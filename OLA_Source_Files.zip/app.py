from pathlib import Path
import sys
import streamlit as st
import pandas as pd
import plotly.express as px

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from streamlit_app.database import get_connection, read_query, DB_PATH

st.set_page_config(page_title="OLA Ride Insights", page_icon="🚕", layout="wide")

st.markdown("""
<style>
.block-container {padding-top: 1.4rem; padding-bottom: 2rem;}
[data-testid="stMetric"] {background: rgba(120,120,120,.08); padding: 14px; border-radius: 12px;}
</style>
""", unsafe_allow_html=True)

st.title("🚕 OLA Ride Insights")
st.caption("End-to-end ride booking analytics | SQLite-powered business intelligence")

if not DB_PATH.exists():
    st.error("Database not found. First run `python src/run_pipeline.py` from the project folder.")
    st.stop()

with get_connection() as conn:
    tables = pd.read_sql_query(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='bookings'", conn
    )
    if tables.empty:
        st.error("The bookings table is missing. Run the ETL pipeline.")
        st.stop()
    cols = [r[1] for r in conn.execute("PRAGMA table_info(bookings)").fetchall()]

def has(col):
    return col in cols

df = read_query("SELECT * FROM bookings")
if df.empty:
    st.warning("The bookings table contains no records.")
    st.stop()

# Sidebar filters are applied only when corresponding columns exist.
st.sidebar.header("Filters")
filtered = df.copy()
if has("booking_status"):
    opts = sorted(filtered["booking_status"].dropna().astype(str).unique().tolist())
    selected = st.sidebar.multiselect("Booking status", opts, default=opts)
    if selected:
        filtered = filtered[filtered["booking_status"].astype(str).isin(selected)]
if has("vehicle_type"):
    opts = sorted(filtered["vehicle_type"].dropna().astype(str).unique().tolist())
    selected = st.sidebar.multiselect("Vehicle type", opts, default=opts)
    if selected:
        filtered = filtered[filtered["vehicle_type"].astype(str).isin(selected)]
if has("payment_method"):
    opts = sorted(filtered["payment_method"].dropna().astype(str).unique().tolist())
    selected = st.sidebar.multiselect("Payment method", opts, default=opts)
    if selected:
        filtered = filtered[filtered["payment_method"].astype(str).isin(selected)]

st.subheader("Executive overview")
total = len(filtered)
successful = int(filtered["is_successful"].fillna(0).sum()) if has("is_successful") else 0
cancelled = int(filtered["is_cancelled"].fillna(0).sum()) if has("is_cancelled") else 0
revenue = float(filtered.loc[filtered["is_successful"].eq(1), "booking_value"].fillna(0).sum()) if has("is_successful") and has("booking_value") else 0
c1,c2,c3,c4 = st.columns(4)
c1.metric("Total bookings", f"{total:,}")
c2.metric("Successful bookings", f"{successful:,}")
c3.metric("Cancelled bookings", f"{cancelled:,}")
c4.metric("Successful booking value", f"{revenue:,.2f}")

left, right = st.columns(2)
if has("booking_status"):
    status_df = filtered["booking_status"].fillna("Unknown").value_counts().rename_axis("status").reset_index(name="bookings")
    left.plotly_chart(px.pie(status_df, names="status", values="bookings", hole=.45, title="Booking status breakdown"), use_container_width=True)
if has("vehicle_type"):
    vehicle_df = filtered.groupby("vehicle_type", dropna=False).size().reset_index(name="bookings")
    right.plotly_chart(px.bar(vehicle_df, x="vehicle_type", y="bookings", title="Bookings by vehicle type"), use_container_width=True)

st.subheader("Revenue and ride performance")
left, right = st.columns(2)
if has("payment_method") and has("booking_value"):
    rev = filtered.copy()
    if has("is_successful"):
        rev = rev[rev["is_successful"].eq(1)]
    rev = rev.groupby("payment_method", dropna=False)["booking_value"].sum().reset_index()
    left.plotly_chart(px.bar(rev, x="payment_method", y="booking_value", title="Successful booking value by payment method"), use_container_width=True)
if has("ride_distance") and has("vehicle_type"):
    dist = filtered.groupby("vehicle_type", dropna=False)["ride_distance"].mean().reset_index()
    right.plotly_chart(px.bar(dist, x="vehicle_type", y="ride_distance", title="Average ride distance by vehicle"), use_container_width=True)

st.subheader("Booking explorer")
st.caption(f"Showing {len(filtered):,} of {len(df):,} records")
st.dataframe(filtered, use_container_width=True, hide_index=True)

st.subheader("SQL playground")
st.caption("Read-only SQL against the curated `bookings` table and project views.")
examples = {
    "Booking status summary": "SELECT booking_status, COUNT(*) AS bookings FROM bookings GROUP BY booking_status ORDER BY bookings DESC;",
    "Average distance by vehicle": "SELECT vehicle_type, ROUND(AVG(ride_distance),2) AS avg_distance FROM bookings GROUP BY vehicle_type ORDER BY avg_distance DESC;",
    "Successful booking value": "SELECT ROUND(SUM(booking_value),2) AS successful_value FROM bookings WHERE is_successful=1;",
    "Top 5 customers": "SELECT customer_id, COUNT(*) AS bookings FROM bookings GROUP BY customer_id ORDER BY bookings DESC LIMIT 5;"
}
choice = st.selectbox("Choose an example query", list(examples))
query = st.text_area("SQL query", value=examples[choice], height=130)
if st.button("Run SQL query", type="primary"):
    q = query.strip().lower()
    if not q.startswith("select") or ";" in q.rstrip(";"):
        st.error("Only one read-only SELECT statement is allowed.")
    else:
        try:
            result = read_query(query)
            st.dataframe(result, use_container_width=True, hide_index=True)
            st.success(f"{len(result):,} rows returned.")
        except Exception as exc:
            st.error(f"Query error: {exc}")

st.sidebar.divider()
st.sidebar.caption("Database: ola_analytics.db")
st.sidebar.caption("Source period: July 2024 workbook")
